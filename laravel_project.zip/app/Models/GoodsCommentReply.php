<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GoodsCommentReply extends Model
{
    //
    protected $table = 'goods_comment_reply';

}
