<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecGoodsPrice extends Model
{
    protected  $table = 'spec_goods_price';

    protected $primaryKey = 'id';
}
