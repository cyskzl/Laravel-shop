<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpecImage extends Model
{
    protected  $table = 'spec_image';

    protected $primaryKey = 'spec_image_id';
}
