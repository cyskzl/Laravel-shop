<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GoodsTabCate extends Model
{
    protected $table = 'goods_tab_cate';
}
