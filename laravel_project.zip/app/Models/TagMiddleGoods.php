<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TagMiddleGoods extends Model
{
    protected $table    = 'tags_middle_goods';
}
