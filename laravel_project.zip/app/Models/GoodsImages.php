<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GoodsImages extends Model
{
    protected  $table = 'goods_images';

    protected $primaryKey = 'img_id';


}
