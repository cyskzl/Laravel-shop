<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CateMiddleGoods extends Model
{
    protected  $table = 'cate_middle_goods';
}
