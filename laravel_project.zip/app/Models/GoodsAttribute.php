<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GoodsAttribute extends Model
{
    protected $table = 'goods_attribute';
    protected $primaryKey = 'attr_id';
}
