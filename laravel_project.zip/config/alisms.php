<?php
return [
    'KEY' =>env('ALISMS_KEY',null),
    'SECRETKEY'=>env('ALISMS_SECRETKEY',null),
];